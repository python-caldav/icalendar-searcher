"""Test the value types of properties."""
